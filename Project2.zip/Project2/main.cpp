#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <SFML/Audio.hpp>

class Enemy {
public:
    sf::Sprite sprite;
    sf::Vector2f velocity;
    

    bool destroyed;
    std::vector<sf::Texture> animationFrames;

    Enemy(const std::vector<sf::Texture>& frames, const sf::Vector2f& position, float speed)
        : animationFrames(frames), destroyed(false)
    {
        sprite.setTexture(animationFrames[0]);
        sprite.setPosition(position);
        sprite.setScale(0.05f, 0.05f);

        velocity.x = (static_cast<float>(rand()) / RAND_MAX) * (speed / 8000.0f) - (speed / 1600000.0f);
        velocity.y = (static_cast<float>(rand()) / RAND_MAX) * (speed / 8000.0f) - (speed / 1600000.0f);
    }
};

class Button {
public:
    Button(const sf::Vector2f& position, const sf::Vector2f& size, const sf::Color& idleColor, const sf::Color& hoverColor);

    void handleEvent(const sf::Event& event);
    void update();
    void render(sf::RenderWindow& window);

private:
    sf::RectangleShape shape;
    sf::Color idleColor;
    sf::Color hoverColor;
    bool isHovered;
};

Button::Button(const sf::Vector2f& position, const sf::Vector2f& size, const sf::Color& idleColor, const sf::Color& hoverColor)
    : idleColor(idleColor), hoverColor(hoverColor), isHovered(false)
{
    shape.setPosition(position);
    shape.setSize(size);
    shape.setFillColor(idleColor);
}

void Button::handleEvent(const sf::Event& event)
{
    if (event.type == sf::Event::MouseMoved) {
        sf::Vector2f mousePosition(event.mouseMove.x, event.mouseMove.y);

        if (shape.getGlobalBounds().contains(mousePosition)) {
            // Mouse is hovering over the button
            isHovered = true;
            shape.setFillColor(hoverColor);
        } else {
            // Mouse is not over the button
            isHovered = false;
            shape.setFillColor(idleColor);
        }
    } else if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
        if (isHovered) {
            // Button was clicked
            // Add your desired behavior here
            // For example, you can trigger an action or change game state
        }
    }
}

void Button::update()
{
    // Update button logic if needed
}

void Button::render(sf::RenderWindow& window)
{
    window.draw(shape);
}

int main()
{
    const int windowWidth = 1920;
    const int windowHeight = 1080;

    sf::RenderWindow window(sf::VideoMode(windowWidth, windowHeight), "Hide and Seek");
    sf::Texture backgroundTexture;

    if (!backgroundTexture.loadFromFile("images\\background.jpg")) 
    {
        return -1;
    }
 
    sf::Sprite backgroundSprite(backgroundTexture);
    backgroundSprite.setScale(windowWidth / static_cast<float>(backgroundTexture.getSize().x),windowHeight / static_cast<float>(backgroundTexture.getSize().y));
    std::vector<sf::Texture> player1Textures;
    std::vector<sf::Texture> player2Textures;
    std::vector<sf::Texture> enemyTextures;

    for (int i = 1; i <= 4; ++i)
    {
        sf::Texture texture;
        std::string filename = "images\\frame1_" + std::to_string(i) + ".png";
        if (!texture.loadFromFile(filename))
        {
          
            return -1;
        }
        player1Textures.push_back(texture);
    }

    for (int i = 1; i <= 4; ++i)
    {
        sf::Texture texture;
        std::string filename = "images\\frame2_" + std::to_string(i) + ".png";
        if (!texture.loadFromFile(filename))
        {
            return -1;
        }
        player2Textures.push_back(texture);
    }

     for (int i = 1; i <= 3; ++i)
    {
        sf::Texture texture;
        std::string filename = "images\\frame3_" + std::to_string(i) + ".png";
        if (!texture.loadFromFile(filename))
        {
            return -1;
        }
        enemyTextures.push_back(texture);
    }
    sf::Sprite player1;
    player1.setTexture(player1Textures[0]);
    player1.setPosition(50.0f, windowHeight / 2.0f);
    player1.setScale(0.5f, 0.5f);
    sf::Sprite player2;
    player2.setTexture(player2Textures[0]);
    player2.setPosition(50.0f, windowHeight / 2.0f);
    player2.setScale(1.1f, 1.1f);
      std::vector<Enemy> enemies;
    srand(static_cast<unsigned>(time(nullptr))); 
    for (int i = 0; i < 10; ++i) {
        sf::Vector2f position(rand() % windowWidth, rand() % windowHeight);
        enemies.emplace_back(enemyTextures, position, 200.0f);
        enemies[i].sprite.setScale(0.1f, 0.1f);
    }

    int currentFrame = 0;
    sf::Clock frameClock;
    sf::Time frameTime = sf::seconds(0.2f);
    int currentFrame2 = 0;
    sf::Clock frameClock2;
    sf::Time frameTime2 = sf::seconds(0.2f);
    int player1Score = 0;
    int player2Score = 0;
   float timer = 60.0f;

sf::Font font;
if (!font.loadFromFile("font\\arial.ttf"))
{
    return -1;
}

sf::Text timerText;
timerText.setFont(font);
timerText.setCharacterSize(24);
timerText.setPosition(40, 100);
timerText.setFillColor(sf::Color::Magenta);

    sf::Text player1ScoreText;
    player1ScoreText.setFont(font);
    player1ScoreText.setCharacterSize(24);
    player1ScoreText.setPosition(40, 20);
    player1ScoreText.setFillColor(sf::Color::Magenta);

    sf::Text player2ScoreText;
    player2ScoreText.setFont(font);
    player2ScoreText.setCharacterSize(24);
    player2ScoreText.setPosition(40, 60);
    player2ScoreText.setFillColor(sf::Color::Magenta);
    sf::Texture resumeButtonTexture;
    if (!resumeButtonTexture.loadFromFile("images\\Gui-Score.png"))
    {
        return -1;
    }
    sf::Sprite resumeButton(resumeButtonTexture);
    // resumeButton.setTexture(player2ScoreText);
    // resumeButton.setTexture(resumeButtonTexture);
    resumeButton.setPosition(1.0, 1.0);
    resumeButton.setScale(0.19f, 0.19f);
    sf::Texture pauseButtonTexture;                      



    
    

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
        {
            if (player1.getPosition().y > 0)
            {
                player1.move(0.0f, -0.05f);
                player1.setScale(0.5f, -0.5f);
            }
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
        {
            if (player1.getPosition().y < windowHeight - player1.getGlobalBounds().height)
            {
                player1.move(0.0f, 0.05f);
                player1.setScale(0.5f, 0.5f);
            }
            else
            {
                player1.move(0.0f, 0.05f);
                player1.setScale(0.5f, -0.5f);
            }
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
        {
            if (player1.getPosition().x > 0)
                player1.move(-0.05f, 0.0f);
            player1.setScale(-0.5f, 0.5f);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
        {
            if (player1.getPosition().x < windowWidth - player1.getGlobalBounds().width)
                player1.move(0.05f, 0.0f);
            player1.setScale(0.5f, 0.5f);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
        {
            if (player2.getPosition().y > 0)
            {
                player2.move(0.0f, -0.05f);
                player2.setScale(1.1f, -1.1f);
            }
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
        {
            if (player2.getPosition().y < windowHeight - player2.getGlobalBounds().height)
            {
                player2.move(0.0f, 0.05f);
                player2.setScale(1.1f, 1.1f);
            }
            else
            {
                player2.move(0.0f, 0.05f);
                player2.setScale(1.1f, -1.1f);
            }
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
        {
            if (player2.getPosition().x > 0)
                player2.move(-0.05f, 0.0f);
            player2.setScale(-1.1f, 1.1f);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
        {
            if (player2.getPosition().x < windowWidth - player2.getGlobalBounds().width)
                player2.move(0.05f, 0.0f);
            player2.setScale(1.1f, 1.1f);
        }

   for (auto& enemy : enemies)
    {

    if (!enemy.destroyed)
        {
    enemy.sprite.move(enemy.velocity);
    enemy.sprite.setScale(0.09f, 0.09f);
    if (enemy.sprite.getPosition().x < 0)
        enemy.sprite.setPosition(windowWidth, enemy.sprite.getPosition().y);
    else if (enemy.sprite.getPosition().x > windowWidth)
        enemy.sprite.setPosition(0, enemy.sprite.getPosition().y);
    if (enemy.sprite.getPosition().y < 0)
        enemy.sprite.setPosition(enemy.sprite.getPosition().x, windowHeight);
    else if (enemy.sprite.getPosition().y > windowHeight)
        enemy.sprite.setPosition(enemy.sprite.getPosition().x, 0);
                if (enemy.sprite.getGlobalBounds().intersects(player1.getGlobalBounds()))
                {
                    enemy.destroyed = true;
                

                    ++player1Score;
                }
                else if (enemy.sprite.getGlobalBounds().intersects(player2.getGlobalBounds()))
                {
                    enemy.destroyed = true;
                   
                    ++player2Score;
                }
        }
                     sf::Time elapsedTime = frameClock.getElapsedTime();
                    int frameIndex = static_cast<int>(elapsedTime.asSeconds() / frameTime.asSeconds()) % enemy.animationFrames.size();
                    enemy.sprite.setTexture(enemy.animationFrames[frameIndex]);
                }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) || sf::Keyboard::isKeyPressed(sf::Keyboard::S) ||
            sf::Keyboard::isKeyPressed(sf::Keyboard::A) || sf::Keyboard::isKeyPressed(sf::Keyboard::D))
        {
            if (frameClock.getElapsedTime() >= frameTime)
            {
                frameClock.restart();
                ++currentFrame;
                if (currentFrame >= player1Textures.size())
                    currentFrame = 0;
                player1.setTexture(player1Textures[currentFrame]);
            }
        }
        else
        {
            currentFrame = 0;
            player1.setTexture(player1Textures[currentFrame]);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) || sf::Keyboard::isKeyPressed(sf::Keyboard::Down) ||
            sf::Keyboard::isKeyPressed(sf::Keyboard::Left) || sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
        {
            if (frameClock2.getElapsedTime() >= frameTime2)
            {
                frameClock2.restart();
                ++currentFrame2;
                if (currentFrame2 >= player2Textures.size())
                    currentFrame2 = 0;
                player2.setTexture(player2Textures[currentFrame2]);
            }
        }
        else
        {
            currentFrame2 = 0;
            player2.setTexture(player2Textures[currentFrame2]);
        }

        window.clear();
        window.draw(backgroundSprite);
        window.draw(player1);
        window.draw(player2);
        //  window.draw(resumeButton);
        for (const auto& enemy : enemies)
        {
            if (!enemy.destroyed)
                window.draw(enemy.sprite);
        }
        //   window.draw(resumeButton);
        player1ScoreText.setString("Player 1 Score: " + std::to_string(player1Score));
        player2ScoreText.setString("Player 2 Score: " + std::to_string(player2Score));
        timerText.setString("Timer: " + std::to_string(timer));
       window.draw(resumeButton);
        window.draw(player1ScoreText);
        window.draw(player2ScoreText);
        window.draw(timerText);
        


    
         timer -= 0.0001f;
    if (timer < 0)
    {
        timer = 0;
        // sf::Text player1ScoreText;
        // player1ScoreText.setFont(font);
        // player1ScoreText.setCharacterSize(24);
        // player1ScoreText.setPosition(20, 150);
        // player1ScoreText.setFillColor(sf::Color::White);
        player1ScoreText.setString("Player 1 Score: " + std::to_string(player1Score));

        // sf::Text player2ScoreText;
        // player2ScoreText.setFont(font);
        // player2ScoreText.setCharacterSize(24);
        // player2ScoreText.setPosition(20, 200);
        // player2ScoreText.setFillColor(sf::Color::White);
        player2ScoreText.setString("Player 2 Score: " + std::to_string(player2Score));

         
        window.draw(player1ScoreText);
        window.draw(player2ScoreText);
        window.draw(timerText);
    }
    else
    {
        timerText.setString("Timer: " + std::to_string(timer));
        // window.draw(resumeButton);
        window.draw(timerText);
    }

    window.display();

    }

    return 0;
}